import 'package:flutter/material.dart';

class RecuperarContrasena extends StatelessWidget {

  static const String name = "recuperar_contrasena";

  const RecuperarContrasena({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
          child: Text("Recuperar Contraseña")
      ),
    );
  }
}
