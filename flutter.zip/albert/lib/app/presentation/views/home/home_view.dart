import 'package:albert/app/presentation/views/home/widgets/my_elevated_button.dart';
import 'package:albert/app/presentation/views/login/login_view.dart';
import 'package:albert/app/presentation/views/register/register_view.dart';
import 'package:albert/app/presentation/views/security/recuperar_contrasena.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomeView extends StatelessWidget {

  static const String name = "home_view";

  const HomeView ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home View"),
      ),
      body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              MyElevatedButton(
                  text: "Register",
                  onPressed: () {
                    context.pushNamed(RegisterView.name);
                  }),
              MyElevatedButton(
                  text: "Login",
                  onPressed: () {
                    context.pushNamed(LoginView.name);
                  }),
              MyElevatedButton(
                  text: "Recuperar Contraseña",
                  onPressed: () {
                    context.pushNamed(RecuperarContrasena.name);
                  }),
            ],
          ),
      ),
    );
  }
}