//Manejar todas las rutas de la aplicación

import 'package:albert/app/presentation/views/views_links.dart';
import 'package:go_router/go_router.dart';

final appRouter = GoRouter(

  routes: [
    GoRoute(
      path: '/',
      name: HomeView.name,
      builder: (context, state) => const HomeView(),
    ),
    GoRoute(
      path: '/login',
      name: LoginView.name,
      builder: (context, state) => const LoginView(),
    ),
    GoRoute(
      path: '/register',
      name: RegisterView.name,
      builder: (context, state) => const RegisterView(),
    ),
    GoRoute(
      path: '/recuperar-contrasena',
      name: RecuperarContrasena.name,
      builder: (context, state) => const RecuperarContrasena(),
    ),
  ]

);

